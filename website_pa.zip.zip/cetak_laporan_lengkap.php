<?php
session_start();

// Keamanan: Pastikan yang mengakses adalah dosen yang login dan ada NIM
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'dosen' || !isset($_GET['nim'])) {
    exit('Akses ditolak. Silakan login terlebih dahulu.');
}

require('fpdf/fpdf.php'); // Pastikan library FPDF ada

// Koneksi ke database
$host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'db_pa_akademi';
$conn = new mysqli($host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) { die("Koneksi gagal: " . $conn->connect_error); }

$nim = $_GET['nim'];
$id_dosen = $_SESSION['user_id'];

// === AMBIL SEMUA DATA YANG DIPERLUKAN UNTUK 3 LAPORAN ===

// 1. Data Mahasiswa dan Dosen PA
$mhs_stmt = $conn->prepare("SELECT m.nama_mahasiswa, p.nama_prodi, d.nama_dosen, d.nidn_dosen FROM mahasiswa m JOIN dosen d ON m.id_dosen_pa = d.id_dosen JOIN program_studi p ON m.id_prodi = p.id_prodi WHERE m.nim = ? AND m.id_dosen_pa = ?");
$mhs_stmt->bind_param("si", $nim, $id_dosen);
$mhs_stmt->execute();
$mhs_data = $mhs_stmt->get_result()->fetch_assoc();
if (!$mhs_data) { exit('Data mahasiswa tidak ditemukan atau Anda tidak memiliki akses.'); }
$dosen_pa_name = $mhs_data['nama_dosen'];
$dosen_pa_nidn = $mhs_data['nidn_dosen'];

// 2. Data Riwayat Bimbingan (Logbook)
$logbook_result = $conn->query("SELECT * FROM logbook WHERE nim_mahasiswa = '{$nim}' ORDER BY tanggal_bimbingan ASC");

// 3. Data Kemajuan Studi (Milestones)
$daftar_pencapaian = ['Seminar Proposal', 'Penelitian Selesai', 'Seminar Hasil', 'Ujian Skripsi (Yudisium)', 'Publikasi Jurnal'];
$result_pencapaian = $conn->query("SELECT nama_pencapaian, status, tanggal_selesai FROM pencapaian WHERE nim_mahasiswa = '{$nim}'");
$status_pencapaian = [];
while($row = $result_pencapaian->fetch_assoc()) { $status_pencapaian[$row['nama_pencapaian']] = $row; }

// 4. Data Nilai Kritis (D/E)
$nilai_kritis_result = $conn->query("SELECT nama_mk, semester_diambil, nilai_huruf FROM nilai_mahasiswa WHERE nim_mahasiswa = '{$nim}' AND nilai_huruf IN ('D', 'E') ORDER BY semester_diambil ASC");


// === MULAI MEMBUAT DOKUMEN PDF ===

class PDF extends FPDF {
    function Footer() {
        $this->SetY(-15); $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Dokumen ini dicetak melalui sistem SMART-BA pada ' . date('d/m/Y H:i'),0,0,'L');
        $this->Cell(0,10,'Halaman '.$this->PageNo(),0,0,'R');
    }
}

$pdf = new PDF('P', 'mm', 'A4');
$pdf->AddPage();

// === KOP SURAT (Hanya sekali di halaman pertama) ===
include 'templates/report_header.php';

// === INFORMASI UMUM MAHASISWA ===
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'LAPORAN LENGKAP MAHASISWA', 0, 1, 'C');
$pdf->Ln(5);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 7, 'Nama Mahasiswa', 0, 0); $pdf->Cell(5, 7, ':', 0, 0); $pdf->Cell(0, 7, $mhs_data['nama_mahasiswa'], 0, 1);
$pdf->Cell(40, 7, 'NIM', 0, 0); $pdf->Cell(5, 7, ':', 0, 0); $pdf->Cell(0, 7, $nim, 0, 1);
$pdf->Cell(40, 7, 'Program Studi', 0, 0); $pdf->Cell(5, 7, ':', 0, 0); $pdf->Cell(0, 7, $mhs_data['nama_prodi'], 0, 1);
$pdf->Ln(10);

// === BAGIAN 1: RIWAYAT BIMBINGAN ===
$pdf->SetFont('Arial', 'B', 12); $pdf->SetFillColor(230, 230, 230);
$pdf->Cell(0, 10, 'BAGIAN I: RIWAYAT BIMBINGAN AKADEMIK', 1, 1, 'C', true);
$pdf->Cell(10, 10, 'No', 1, 0, 'C'); $pdf->Cell(30, 10, 'Tanggal', 1, 0, 'C');
$pdf->Cell(50, 10, 'Topik', 1, 0, 'C'); $pdf->Cell(100, 10, 'Pembahasan & Tindak Lanjut', 1, 1, 'C');
$pdf->SetFont('Arial', '', 10);
$no = 1;
if ($logbook_result->num_rows > 0) {
    while ($log = $logbook_result->fetch_assoc()) {
        $pdf->Cell(10, 10, $no++, 1, 0, 'C'); $pdf->Cell(30, 10, date('d-m-Y', strtotime($log['tanggal_bimbingan'])), 1, 0, 'C');
        $pdf->Cell(50, 10, $log['topik_bimbingan'], 1, 0);
        $x = $pdf->GetX(); $y = $pdf->GetY();
        $pdf->MultiCell(100, 5, "P: " . $log['isi_bimbingan'] . "\n" . "TL: " . $log['tindak_lanjut'], 0, 'L');
        $pdf->SetXY($x + 100, $y); $pdf->Cell(100, 10, '', 1, 1);
    }
} else { $pdf->Cell(190, 10, 'Tidak ada riwayat bimbingan.', 1, 1, 'C'); }
$pdf->Ln(10);

// === BAGIAN 2: KEMAJUAN STUDI ===
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'BAGIAN II: KEMAJUAN STUDI (MILESTONES)', 1, 1, 'C', true);
$pdf->Cell(10, 10, 'No', 1, 0, 'C'); $pdf->Cell(100, 10, 'Pencapaian', 1, 0, 'C');
$pdf->Cell(40, 10, 'Status', 1, 0, 'C'); $pdf->Cell(40, 10, 'Tanggal Selesai', 1, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$no = 1;
foreach ($daftar_pencapaian as $item) {
    $status = 'Belum Selesai'; $tanggal = '-';
    if (isset($status_pencapaian[$item]) && $status_pencapaian[$item]['status'] == 'Selesai') {
        $status = 'Selesai'; $tanggal = !empty($status_pencapaian[$item]['tanggal_selesai']) ? date('d-m-Y', strtotime($status_pencapaian[$item]['tanggal_selesai'])) : '-';
    }
    $pdf->Cell(10, 10, $no++, 1, 0, 'C'); $pdf->Cell(100, 10, $item, 1, 0);
    $pdf->Cell(40, 10, $status, 1, 0, 'C'); $pdf->Cell(40, 10, $tanggal, 1, 1, 'C');
}
$pdf->Ln(10);

// === BAGIAN 3: NILAI KRITIS ===
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'BAGIAN III: LAPORAN NILAI KRITIS (D/E)', 1, 1, 'C', true);
$pdf->Cell(15, 10, 'No', 1, 0, 'C'); $pdf->Cell(115, 10, 'Nama Mata Kuliah', 1, 0, 'C');
$pdf->Cell(30, 10, 'Semester', 1, 0, 'C'); $pdf->Cell(30, 10, 'Nilai', 1, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$no = 1;
if ($nilai_kritis_result->num_rows > 0) {
    while ($nilai = $nilai_kritis_result->fetch_assoc()) {
        $pdf->Cell(15, 10, $no++, 1, 0, 'C'); $pdf->Cell(115, 10, $nilai['nama_mk'], 1, 0);
        $pdf->Cell(30, 10, $nilai['semester_diambil'], 1, 0, 'C');
        $pdf->SetFont('Arial', 'B', 12); $pdf->SetTextColor(220, 53, 69);
        $pdf->Cell(30, 10, $nilai['nilai_huruf'], 1, 1, 'C');
        $pdf->SetFont('Arial', '', 12); $pdf->SetTextColor(0, 0, 0);
    }
} else { $pdf->Cell(190, 10, 'Tidak ada laporan nilai kritis.', 1, 1, 'C'); }

// === TANDA TANGAN (Hanya sekali di akhir dokumen) ===
include 'templates/report_footer.php';

$pdf->Output('D', 'Laporan_Lengkap_' . $nim . '.pdf');
$conn->close();
?>