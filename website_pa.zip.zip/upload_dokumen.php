<?php
session_start();

// Keamanan: Hanya mahasiswa yang bisa mengakses
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'mahasiswa') {
    $_SESSION['upload_message'] = "Akses ditolak.";
    $_SESSION['upload_status'] = "error";
    header("Location: dashboard_mahasiswa.php");
    exit();
}

// Cek apakah ada file yang diunggah
if (isset($_FILES['file_dokumen']) && $_FILES['file_dokumen']['error'] == 0) {
    
    $nim_mahasiswa = $_SESSION['user_id'];
    $judul_dokumen = $_POST['judul_dokumen'];

    // Pengaturan file
    $target_dir = "uploads/";
    $original_filename = basename($_FILES["file_dokumen"]["name"]);
    $file_extension = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));
    // Buat nama file unik untuk menghindari konflik
    $new_filename = $nim_mahasiswa . "_" . time() . "." . $file_extension;
    $target_file = $target_dir . $new_filename;
    
    // Validasi
    $allowed_types = ['pdf', 'doc', 'docx'];
    if (!in_array($file_extension, $allowed_types)) {
        $_SESSION['upload_message'] = "Error: Hanya file PDF, DOC, dan DOCX yang diizinkan.";
        $_SESSION['upload_status'] = "error";
        header("Location: dashboard_mahasiswa.php");
        exit();
    }
    if ($_FILES["file_dokumen"]["size"] > 5000000) { // 5MB
        $_SESSION['upload_message'] = "Error: Ukuran file terlalu besar. Maksimal 5MB.";
        $_SESSION['upload_status'] = "error";
        header("Location: dashboard_mahasiswa.php");
        exit();
    }

    // Pindahkan file ke folder 'uploads'
    if (move_uploaded_file($_FILES["file_dokumen"]["tmp_name"], $target_file)) {
        
        // Simpan informasi ke database
        $host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'db_pa_akademi';
        $conn = new mysqli($host, $db_user, $db_pass, $db_name);

        // Ambil ID Dosen
        $dosen_id_result = $conn->query("SELECT id_dosen_pa FROM mahasiswa WHERE nim = '$nim_mahasiswa'");
        $id_dosen = $dosen_id_result->fetch_assoc()['id_dosen_pa'];
        
        $stmt = $conn->prepare("INSERT INTO dokumen (nim_mahasiswa, id_dosen, judul_dokumen, nama_file, path_file, tipe_file, ukuran_file) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $tipe_file = $_FILES['file_dokumen']['type'];
        $ukuran_file = $_FILES['file_dokumen']['size'];
        $stmt->bind_param("sissssi", $nim_mahasiswa, $id_dosen, $judul_dokumen, $new_filename, $target_file, $tipe_file, $ukuran_file);
        
        if ($stmt->execute()) {
            $_SESSION['upload_message'] = "File '". htmlspecialchars($original_filename) ."' berhasil diunggah.";
            $_SESSION['upload_status'] = "success";
        } else {
            $_SESSION['upload_message'] = "Error: Gagal menyimpan data file ke database.";
            $_SESSION['upload_status'] = "error";
        }
        $conn->close();

    } else {
        $_SESSION['upload_message'] = "Error: Terjadi kesalahan saat mengunggah file.";
        $_SESSION['upload_status'] = "error";
    }

} else {
    $_SESSION['upload_message'] = "Error: Tidak ada file yang dipilih atau terjadi kesalahan unggah.";
    $_SESSION['upload_status'] = "error";
}

header("Location: dashboard_mahasiswa.php");
exit();
?>